# Vehicle > 2024-05-17 2:05am
https://universe.roboflow.com/nvidia-workspace/vehicle-czcp0

Provided by a Roboflow user
License: CC BY 4.0

